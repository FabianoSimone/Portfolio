import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from '../app/components/app/app.component';
import { HomeComponent } from './components/home/home.component';
import { BannerComponent } from './components/banner/banner.component';
import { FooterComponent } from './components/footer/footer.component';
import { NavComponent } from './components/nav/nav.component';
import { WishlistComponent } from './components/wishlist/wishlist.component';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { CategoriesComponent } from './components/categories/categories.component';
import { ProductsComponent } from './components/products/products.component';
import { OfferComponent } from './components/offer/offer.component';
import { TestimonialComponent } from './components/testimonial/testimonial.component';
import { BrandsComponent } from './components/brands/brands.component';
import { ProductDetailsComponent } from './components/product-details/product-details.component';
import { CartComponent } from './components/cart/cart.component';
import { SideNavigationComponent } from './components/side-navigation/side-navigation.component';
import { OrdersComponent } from './components/orders/orders.component';
import { MyAreaComponent } from './components/my-area/my-area.component';
import { JwtHelperService, JwtModule, JWT_OPTIONS } from '@auth0/angular-jwt';
import { FormsModule } from '@angular/forms';

import { AddLibroComponent } from './components/add-libro/add-libro.component';

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    BannerComponent,
    FooterComponent,
    NavComponent,
    WishlistComponent,
    LoginComponent,
    RegisterComponent,
    CategoriesComponent,
    ProductsComponent,
    OfferComponent,
    TestimonialComponent,
    BrandsComponent,
    ProductDetailsComponent,
    CartComponent,
    SideNavigationComponent,
    OrdersComponent,
    MyAreaComponent,
    AddLibroComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [
    {
      provide:JWT_OPTIONS,
      useValue:JWT_OPTIONS
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
