import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable, Input } from '@angular/core';
import { JwtHelperService } from '@auth0/angular-jwt';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  role?:any;
  username?:any;

  @Input()
  isLogged: boolean|undefined;

  @Input()
  adminMode: boolean|undefined;

  constructor(private http: HttpClient, private router: Router, private jwtHelper: JwtHelperService) { }

  CheckUser():void{
    this.role = this.GetUserRole();
    this.username = this.GetUsername();
    const token = this.tokenGetter();
    if (token) {
      this.isLogged = true;
      if(this.role === 'Basic'){
        this.adminMode = false;
      } else {
        this.adminMode = true;
      }
    }else
    this.isLogged = false;

    console.log('logged?: ' + this.isLogged);
    console.log('role: ' + this.role);
    console.log('username: ' + this.username);
    console.log('adminMode?: ' + this.adminMode);
  }

  GetUserRole(){
    const token = this.tokenGetter();
    if(!token) {
      return
    }
    let tokenData = this.jwtHelper.decodeToken(token);
    let role = tokenData['http://schemas.microsoft.com/ws/2008/06/identity/claims/role'];
    return role;
  }

  GetUsername(){
    const token = this.tokenGetter();
    if(!token){
      return
    }
    let tokenData = this.jwtHelper.decodeToken(token);
    let username = tokenData['http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name'];
    return username;
  }

  tokenGetter() {
    return localStorage.getItem("jwt");
  } 

  LogOut(){
    return localStorage.removeItem("jwt")
    
  }

  Login(form: NgForm) {
    const credentials = JSON.stringify(form.value);
    this.http.post("https://localhost:44394/api/Authentication/login", credentials, {
      headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    }).subscribe(response => {
      const token = (<any>response).token;
      localStorage.setItem("jwt", token);
      this.router.navigate(["home"]);
    }, err => {
    });
  }
  
  Register(form: NgForm) {
    const data = JSON.stringify(form.value);
    this.http.post("https://localhost:44347/api/Authentication/newUser", data, {
           headers: new HttpHeaders({
        "Content-Type": "application/json"
      })
    }).subscribe(response => {
      console.log(response);
      this.router.navigate(["login"]);
    }, err => {
    });
  }

}
