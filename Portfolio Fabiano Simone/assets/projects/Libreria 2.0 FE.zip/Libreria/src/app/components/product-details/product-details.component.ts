import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.scss']
})
export class ProductDetailsComponent implements OnInit {
  wishlists: boolean[] = [
    false,
    false,
    false,
    false,
    false];

  carts: boolean[] = [
    false,
    false,
    false,
    false,
    false];
  constructor() { }

  ngOnInit(): void {
  }

}
