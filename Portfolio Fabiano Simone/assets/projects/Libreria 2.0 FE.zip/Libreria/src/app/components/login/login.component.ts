import { Component, OnInit } from '@angular/core';
import { NgForm, FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from 'src/app/services/auth.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  username: string="";
  password: string="";

  constructor(private authService: AuthService) { }

  SignIn(form: NgForm): void {
    this.authService.Login(form);
  }

  ngOnInit(): void {
  }

}
