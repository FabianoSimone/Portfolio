import { Component, DoCheck, OnInit } from '@angular/core';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.scss']
})
export class CartComponent implements OnInit,DoCheck {
  totale_parziale=1;
  elimina:boolean[]=[
    false,
    false,
    false
  ];
  wishlists:boolean[]=[
    false,
    false,
    false
  ];

  parziale:number=0;
  iva:number=0;
  totale:number=0;

  constructor() { 
   
  }
  ngDoCheck(): void {
    
    this.parziale=0;
    this.totale=0;
    for (let index = 0; index < this.elimina.length; index++) {
      if(!this.elimina[index])
      {
        this.parziale=this.parziale+50;
        
      }
      this.iva=this.parziale*0.22;
      this.totale=this.parziale+this.iva+10;
    }
  }

  
  
  ngOnInit(): void {
    
  }


}
