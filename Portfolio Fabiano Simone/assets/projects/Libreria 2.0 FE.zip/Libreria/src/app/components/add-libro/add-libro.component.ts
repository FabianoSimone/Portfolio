import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-libro',
  templateUrl: './add-libro.component.html',
  styleUrls: ['./add-libro.component.scss']
})
export class AddLibroComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
