import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-area',
  templateUrl: './my-area.component.html',
  styleUrls: ['./my-area.component.scss']
})
export class MyAreaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
