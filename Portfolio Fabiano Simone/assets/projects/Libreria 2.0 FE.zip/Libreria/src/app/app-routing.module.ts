import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddLibroComponent } from './components/add-libro/add-libro.component';
import { CartComponent } from './components/cart/cart.component';
import { HomeComponent } from './components/home/home.component';
import { LoginComponent } from './components/login/login.component';
import { MyAreaComponent } from './components/my-area/my-area.component';
import { OrdersComponent } from './components/orders/orders.component';
import { ProductDetailsComponent } from './components/product-details/product-details.component';
import { RegisterComponent } from './components/register/register.component';
import { SideNavigationComponent } from './components/side-navigation/side-navigation.component';
import { WishlistComponent } from './components/wishlist/wishlist.component';
const routes: Routes = [
  {
    path:"",
    component:HomeComponent
  },
  {
    path: "login",
    component: LoginComponent
  },
  {
    path:"wishlist",
    component:WishlistComponent
  },
  {
    path:"register",
    component:RegisterComponent
  },
  {
    path:"product-details",
    component:ProductDetailsComponent
  },
  {
    path:"cart",
    component:CartComponent
  },
  {
    path:"side-navigation",
    component:SideNavigationComponent
  },
  {
    path:"orders",
    component:OrdersComponent
  },
  {
    path:"my-area",
    component:MyAreaComponent
  },
  {
    path:"addLibro",
    component:AddLibroComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
