﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class TesarDBContext : DbContext
    {
        public TesarDBContext()
        {
        }

        public TesarDBContext(DbContextOptions<TesarDBContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Anagrafe> Anagraves { get; set; }
        public virtual DbSet<Articolo> Articolos { get; set; }
        public virtual DbSet<Coordinatum> Coordinata { get; set; }
        public virtual DbSet<Errore> Errores { get; set; }
        public virtual DbSet<Macchina> Macchinas { get; set; }
        public virtual DbSet<MacchinaErrore> MacchinaErrores { get; set; }
        public virtual DbSet<MacchinaOrdine> MacchinaOrdines { get; set; }
        public virtual DbSet<Operatore> Operatores { get; set; }
        public virtual DbSet<OperatoreMacchina> OperatoreMacchinas { get; set; }
        public virtual DbSet<Ordine> Ordines { get; set; }
        public virtual DbSet<Reparto> Repartos { get; set; }
        public virtual DbSet<Stabilimento> Stabilimentos { get; set; }
        public virtual DbSet<Stato> Statos { get; set; }
        public virtual DbSet<Template> Templates { get; set; }
        public virtual DbSet<User> Users { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
                optionsBuilder.UseSqlServer("Server=tcp:servertesar.database.windows.net,1433;Initial Catalog=TesarDB;Persist Security Info=False;User ID=localadmin;Password=Paperino123*;MultipleActiveResultSets=False;Encrypt=True;TrustServerCertificate=False;Connection Timeout=30;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.HasAnnotation("Relational:Collation", "SQL_Latin1_General_CP1_CI_AS");

            modelBuilder.Entity<Anagrafe>(entity =>
            {
                entity.ToTable("Anagrafe");

                entity.Property(e => e.Id)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("id");

                entity.Property(e => e.Cognome)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("cognome");

                entity.Property(e => e.DataNascita)
                    .HasColumnType("date")
                    .HasColumnName("dataNascita");

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("nome");

                entity.Property(e => e.UserId)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("userId");

                entity.HasOne(d => d.User)
                    .WithMany(p => p.Anagraves)
                    .HasForeignKey(d => d.UserId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Anagrafe_User");
            });

            modelBuilder.Entity<Articolo>(entity =>
            {
                entity.ToTable("Articolo");

                entity.Property(e => e.ArticoloId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("articoloId");

                entity.Property(e => e.Materiale)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("materiale");

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("nome");

                entity.Property(e => e.Peso)
                    .HasColumnType("numeric(4, 3)")
                    .HasColumnName("peso");
            });

            modelBuilder.Entity<Coordinatum>(entity =>
            {
                entity.Property(e => e.Id)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.CoordinateX)
                    .HasColumnType("numeric(18, 5)")
                    .HasColumnName("coordinateX");

                entity.Property(e => e.CoordinateY)
                    .HasColumnType("numeric(18, 5)")
                    .HasColumnName("coordinateY");

                entity.Property(e => e.MacchinaId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("macchinaId");

                entity.Property(e => e.RepartoId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("repartoId");

                entity.HasOne(d => d.Macchina)
                    .WithMany(p => p.Coordinata)
                    .HasForeignKey(d => d.MacchinaId)
                    .HasConstraintName("FK_Coordinata_Macchina");

                entity.HasOne(d => d.Reparto)
                    .WithMany(p => p.Coordinata)
                    .HasForeignKey(d => d.RepartoId)
                    .HasConstraintName("FK_coordinate_Reparto");
            });

            modelBuilder.Entity<Errore>(entity =>
            {
                entity.ToTable("Errore");

                entity.Property(e => e.ErroreId)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("erroreId");

                entity.Property(e => e.Descizione)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("descizione");

                entity.Property(e => e.Tipo)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("tipo");
            });

            modelBuilder.Entity<Macchina>(entity =>
            {
                entity.ToTable("Macchina");

                entity.Property(e => e.MacchinaId)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("macchinaId");

                entity.Property(e => e.Cancellato).HasColumnName("cancellato");

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("nome");

                entity.Property(e => e.Quantitaprodotta)
                    .HasColumnType("numeric(10, 0)")
                    .HasColumnName("quantitaprodotta");

                entity.Property(e => e.RepartoId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("repartoId");

                entity.Property(e => e.StatoId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("statoId");

                entity.Property(e => e.Tipolavorazione)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("tipolavorazione");

                entity.HasOne(d => d.Reparto)
                    .WithMany(p => p.Macchinas)
                    .HasForeignKey(d => d.RepartoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Macchine_Reparto");

                entity.HasOne(d => d.Stato)
                    .WithMany(p => p.Macchinas)
                    .HasForeignKey(d => d.StatoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Macchine_Stati");
            });

            modelBuilder.Entity<MacchinaErrore>(entity =>
            {
                entity.HasKey(e => new { e.MacchinaId, e.ErroreId, e.Data })
                    .HasName("PK__Macchina__DA296D038EB57A95");

                entity.ToTable("Macchina_Errore");

                entity.Property(e => e.MacchinaId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("macchinaId");

                entity.Property(e => e.ErroreId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("erroreId");

                entity.Property(e => e.Data)
                    .HasColumnType("datetime")
                    .HasColumnName("data");

                entity.Property(e => e.Priorita)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("priorita");

                entity.Property(e => e.Risolto).HasColumnName("risolto");

                entity.HasOne(d => d.Errore)
                    .WithMany(p => p.MacchinaErrores)
                    .HasForeignKey(d => d.ErroreId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Macchina___error__09A971A2");

                entity.HasOne(d => d.Macchina)
                    .WithMany(p => p.MacchinaErrores)
                    .HasForeignKey(d => d.MacchinaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Macchina___macch__08B54D69");
            });

            modelBuilder.Entity<MacchinaOrdine>(entity =>
            {
                entity.HasKey(e => new { e.MacchinaId, e.OrdineId })
                    .HasName("PK__Macchina__9FCFC2FBB6250AB6");

                entity.ToTable("Macchina_Ordine");

                entity.Property(e => e.MacchinaId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("macchinaId");

                entity.Property(e => e.OrdineId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("ordineId");

                entity.HasOne(d => d.Macchina)
                    .WithMany(p => p.MacchinaOrdines)
                    .HasForeignKey(d => d.MacchinaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Macchina___macch__22751F6C");

                entity.HasOne(d => d.Ordine)
                    .WithMany(p => p.MacchinaOrdines)
                    .HasForeignKey(d => d.OrdineId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Macchina___ordin__236943A5");
            });

            modelBuilder.Entity<Operatore>(entity =>
            {
                entity.HasKey(e => e.OperatorId)
                    .HasName("PK_operatori");

                entity.ToTable("Operatore");

                entity.Property(e => e.OperatorId)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("operatorId");

                entity.Property(e => e.AnagrafeId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("anagrafeId");

                entity.Property(e => e.Attivo).HasColumnName("attivo");

                entity.Property(e => e.Immagine)
                    .IsUnicode(false)
                    .HasColumnName("immagine");

                entity.Property(e => e.Ruolo)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("ruolo");

                entity.HasOne(d => d.Anagrafe)
                    .WithMany(p => p.Operatores)
                    .HasForeignKey(d => d.AnagrafeId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_operatori_Anagrafe");
            });

            modelBuilder.Entity<OperatoreMacchina>(entity =>
            {
                entity.HasKey(e => new { e.OperatoreId, e.MacchinaId })
                    .HasName("PK__Operator__B6EB96D0D81D9B8E");

                entity.ToTable("Operatore_Macchina");

                entity.Property(e => e.OperatoreId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("operatoreId");

                entity.Property(e => e.MacchinaId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("macchinaId");

                entity.HasOne(d => d.Macchina)
                    .WithMany(p => p.OperatoreMacchinas)
                    .HasForeignKey(d => d.MacchinaId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Operatore__macch__2739D489");

                entity.HasOne(d => d.Operatore)
                    .WithMany(p => p.OperatoreMacchinas)
                    .HasForeignKey(d => d.OperatoreId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK__Operatore__opera__2645B050");
            });

            modelBuilder.Entity<Ordine>(entity =>
            {
                entity.ToTable("Ordine");

                entity.Property(e => e.OrdineId)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("ordineId");

                entity.Property(e => e.ArticoloId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("articoloId");

                entity.Property(e => e.Data)
                    .HasColumnType("date")
                    .HasColumnName("data");

                entity.Property(e => e.MacchinaId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("macchinaId");

                entity.Property(e => e.Quantita)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("quantita");

                entity.HasOne(d => d.Articolo)
                    .WithMany(p => p.Ordines)
                    .HasForeignKey(d => d.ArticoloId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Ordine_Articoli");
            });

            modelBuilder.Entity<Reparto>(entity =>
            {
                entity.ToTable("Reparto");

                entity.Property(e => e.RepartoId)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("repartoId");

                entity.Property(e => e.Cancellato).HasColumnName("cancellato");

                entity.Property(e => e.Mappa)
                    .IsRequired()
                    .IsUnicode(false)
                    .HasColumnName("mappa");

                entity.Property(e => e.NomeReparto)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("nomeReparto");

                entity.Property(e => e.ResponsabileId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("responsabileId");

                entity.Property(e => e.StabilimentoId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("stabilimentoId");
            });

            modelBuilder.Entity<Stabilimento>(entity =>
            {
                entity.ToTable("Stabilimento");

                entity.Property(e => e.StabilimentoId)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd();

                entity.Property(e => e.Citta)
                    .IsRequired()
                    .IsUnicode(false);

                entity.Property(e => e.Mappa).IsUnicode(false);

                entity.Property(e => e.Nome)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false);
            });

            modelBuilder.Entity<Stato>(entity =>
            {
                entity.ToTable("Stato");

                entity.Property(e => e.StatoId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("statoId");

                entity.Property(e => e.Stato1)
                    .IsRequired()
                    .HasMaxLength(20)
                    .IsUnicode(false)
                    .HasColumnName("stato");
            });

            modelBuilder.Entity<Template>(entity =>
            {
                entity.HasNoKey();

                entity.ToTable("Template");

                entity.Property(e => e.Html).HasColumnName("html");

                entity.Property(e => e.RepartoId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("repartoId");

                entity.Property(e => e.StabilimentoId)
                    .HasColumnType("numeric(18, 0)")
                    .HasColumnName("stabilimentoId");

                entity.Property(e => e.TemplateId)
                    .HasColumnType("numeric(18, 0)")
                    .ValueGeneratedOnAdd()
                    .HasColumnName("templateId");

                entity.HasOne(d => d.Reparto)
                    .WithMany()
                    .HasForeignKey(d => d.RepartoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Template_Reparto");

                entity.HasOne(d => d.Stabilimento)
                    .WithMany()
                    .HasForeignKey(d => d.StabilimentoId)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_Template_Stabilimento");
            });

            modelBuilder.Entity<User>(entity =>
            {
                entity.HasKey(e => e.Username)
                    .HasName("PK_Username");

                entity.ToTable("User");

                entity.Property(e => e.Username)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("username");

                entity.Property(e => e.Admin).HasColumnName("admin");

                entity.Property(e => e.ConcurrencyStamp)
                    .HasMaxLength(258)
                    .IsUnicode(false);

                entity.Property(e => e.Email)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("email");

                entity.Property(e => e.NormalizedEmail)
                    .HasMaxLength(258)
                    .IsUnicode(false);

                entity.Property(e => e.NormalizedUserName)
                    .HasMaxLength(258)
                    .IsUnicode(false);

                entity.Property(e => e.Password)
                    .IsRequired()
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("password");

                entity.Property(e => e.PasswordHash)
                    .HasMaxLength(258)
                    .IsUnicode(false);

                entity.Property(e => e.PhoneNumber)
                    .HasMaxLength(258)
                    .IsUnicode(false);

                entity.Property(e => e.SecurityStamp)
                    .HasMaxLength(258)
                    .IsUnicode(false);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
