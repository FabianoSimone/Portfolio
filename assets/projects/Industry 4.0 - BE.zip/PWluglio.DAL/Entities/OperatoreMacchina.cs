﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class OperatoreMacchina
    {
        public decimal OperatoreId { get; set; }
        public decimal MacchinaId { get; set; }

        public virtual Macchina Macchina { get; set; }
        public virtual Operatore Operatore { get; set; }
    }
}
