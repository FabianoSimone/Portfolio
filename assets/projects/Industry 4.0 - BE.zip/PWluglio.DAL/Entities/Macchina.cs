﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class Macchina
    {
        public Macchina()
        {
            Coordinata = new HashSet<Coordinatum>();
            MacchinaErrores = new HashSet<MacchinaErrore>();
            MacchinaOrdines = new HashSet<MacchinaOrdine>();
            OperatoreMacchinas = new HashSet<OperatoreMacchina>();
        }

        public decimal MacchinaId { get; set; }
        public string Nome { get; set; }
        public string Tipolavorazione { get; set; }
        public decimal Quantitaprodotta { get; set; }
        public decimal RepartoId { get; set; }
        public decimal StatoId { get; set; }
        public bool Cancellato { get; set; }

        public virtual Reparto Reparto { get; set; }
        public virtual Stato Stato { get; set; }
        public virtual ICollection<Coordinatum> Coordinata { get; set; }
        public virtual ICollection<MacchinaErrore> MacchinaErrores { get; set; }
        public virtual ICollection<MacchinaOrdine> MacchinaOrdines { get; set; }
        public virtual ICollection<OperatoreMacchina> OperatoreMacchinas { get; set; }
    }
}
