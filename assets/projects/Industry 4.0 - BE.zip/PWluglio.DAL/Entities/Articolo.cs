﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class Articolo
    {
        public Articolo()
        {
            Ordines = new HashSet<Ordine>();
        }

        public decimal ArticoloId { get; set; }
        public string Nome { get; set; }
        public string Materiale { get; set; }
        public decimal Peso { get; set; }

        public virtual ICollection<Ordine> Ordines { get; set; }
    }
}
