﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class MacchinaErrore
    {
        public decimal MacchinaId { get; set; }
        public decimal ErroreId { get; set; }
        public string Priorita { get; set; }
        public DateTime Data { get; set; }
        public bool Risolto { get; set; }

        public virtual Errore Errore { get; set; }
        public virtual Macchina Macchina { get; set; }
    }
}
