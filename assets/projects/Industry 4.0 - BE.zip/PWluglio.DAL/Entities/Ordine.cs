﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class Ordine
    {
        public Ordine()
        {
            MacchinaOrdines = new HashSet<MacchinaOrdine>();
        }

        public decimal OrdineId { get; set; }
        public DateTime Data { get; set; }
        public decimal Quantita { get; set; }
        public decimal ArticoloId { get; set; }
        public decimal MacchinaId { get; set; }

        public virtual Articolo Articolo { get; set; }
        public virtual ICollection<MacchinaOrdine> MacchinaOrdines { get; set; }
    }
}
