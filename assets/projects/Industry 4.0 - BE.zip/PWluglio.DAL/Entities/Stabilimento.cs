﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class Stabilimento
    {
        public decimal StabilimentoId { get; set; }
        public string Nome { get; set; }
        public string Citta { get; set; }
        public string Mappa { get; set; }
    }
}
