﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class MacchinaOrdine
    {
        public decimal MacchinaId { get; set; }
        public decimal OrdineId { get; set; }

        public virtual Macchina Macchina { get; set; }
        public virtual Ordine Ordine { get; set; }
    }
}
