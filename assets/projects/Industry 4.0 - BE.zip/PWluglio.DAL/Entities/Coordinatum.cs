﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class Coordinatum
    {
        public decimal Id { get; set; }
        public decimal? RepartoId { get; set; }
        public decimal? MacchinaId { get; set; }
        public decimal CoordinateX { get; set; }
        public decimal CoordinateY { get; set; }

        public virtual Macchina Macchina { get; set; }
        public virtual Reparto Reparto { get; set; }
    }
}
