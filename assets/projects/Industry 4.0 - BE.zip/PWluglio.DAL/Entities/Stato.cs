﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class Stato
    {
        public Stato()
        {
            Macchinas = new HashSet<Macchina>();
        }

        public decimal StatoId { get; set; }
        public string Stato1 { get; set; }

        public virtual ICollection<Macchina> Macchinas { get; set; }
    }
}
