﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class Template
    {
        public decimal TemplateId { get; set; }
        public byte[] Html { get; set; }
        public decimal RepartoId { get; set; }
        public decimal StabilimentoId { get; set; }

        public virtual Reparto Reparto { get; set; }
        public virtual Stabilimento Stabilimento { get; set; }
    }
}
