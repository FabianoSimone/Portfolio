﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class Anagrafe
    {
        public Anagrafe()
        {
            Operatores = new HashSet<Operatore>();
        }

        public decimal Id { get; set; }
        public string Nome { get; set; }
        public string Cognome { get; set; }
        public DateTime DataNascita { get; set; }
        public string UserId { get; set; }

        public virtual User User { get; set; }
        public virtual ICollection<Operatore> Operatores { get; set; }
    }
}
