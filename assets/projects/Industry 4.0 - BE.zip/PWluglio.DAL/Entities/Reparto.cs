﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class Reparto
    {
        public Reparto()
        {
            Coordinata = new HashSet<Coordinatum>();
            Macchinas = new HashSet<Macchina>();
        }

        public decimal RepartoId { get; set; }
        public string NomeReparto { get; set; }
        public decimal ResponsabileId { get; set; }
        public decimal StabilimentoId { get; set; }
        public string Mappa { get; set; }
        public bool Cancellato { get; set; }

        public virtual ICollection<Coordinatum> Coordinata { get; set; }
        public virtual ICollection<Macchina> Macchinas { get; set; }
    }
}
