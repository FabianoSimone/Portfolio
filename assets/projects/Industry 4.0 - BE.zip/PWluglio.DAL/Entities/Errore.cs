﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class Errore
    {
        public Errore()
        {
            MacchinaErrores = new HashSet<MacchinaErrore>();
        }

        public decimal ErroreId { get; set; }
        public string Tipo { get; set; }
        public string Descizione { get; set; }

        public virtual ICollection<MacchinaErrore> MacchinaErrores { get; set; }
    }
}
