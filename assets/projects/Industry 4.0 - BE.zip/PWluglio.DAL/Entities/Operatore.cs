﻿using System;
using System.Collections.Generic;

#nullable disable

namespace PWluglio.DAL.Entities
{
    public partial class Operatore
    {
        public Operatore()
        {
            OperatoreMacchinas = new HashSet<OperatoreMacchina>();
        }

        public decimal OperatorId { get; set; }
        public string Ruolo { get; set; }
        public decimal AnagrafeId { get; set; }
        public string Immagine { get; set; }
        public bool Attivo { get; set; }

        public virtual Anagrafe Anagrafe { get; set; }
        public virtual ICollection<OperatoreMacchina> OperatoreMacchinas { get; set; }
    }
}
