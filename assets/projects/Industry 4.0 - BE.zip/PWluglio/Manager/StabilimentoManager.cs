﻿using Microsoft.Extensions.Logging;
using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class StabilimentoManager
    {
        static DataMapper mapper = new DataMapper();
        public static bool Add(StabilimentoDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Stabilimentos.Add(mapper.MapDTOToStabilimento(input));
                return context.SaveChanges() > 0;
            }
        }

        public static StabilimentoDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Stabilimento stabilimento = context.Stabilimentos.Find(id);
                if (stabilimento != null)
                {
                    return mapper.MapStabilimentoToDTO(stabilimento);
                }
                return null;
            }
        }
        public static string GetMappa(decimal id)
        {
            using(TesarDBContext context=new TesarDBContext())
            {
               string mappa =  context.Stabilimentos.Single(x => x.StabilimentoId == id).Mappa;
                if(mappa!=null)
                {
                    return mappa;
                }
                return null;

            }
        }

       public static int GetStatoStabilimento(decimal stabilimentoId)
        {
            using(TesarDBContext context=new TesarDBContext())
            {
                int[] countStati=GetCountStatiStabilimento(stabilimentoId);
                for(int i=countStati.Length-1;i>=0;i--)
                {
                    if(countStati[i]!=0)
                    {
                        return i+1;
                    }
                }
                return 1;
            }
        }

        public static int[] GetCountStatiStabilimento(decimal id)//Restituisce il count delle macchine nei vari stati
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                var reparti = context.Repartos.ToList().FindAll(x => x.StabilimentoId == id);
                List<decimal> repartiId = new List<decimal>();
                reparti.ForEach(x => repartiId.Add(x.RepartoId));
                int[] countStati = new int[4];
                List<MacchinaDTO> MacchineNelReparto=null;

                for (int i = 0; i < repartiId.Count; i++)
                {
                    MacchineNelReparto= MacchinaManager.GetAllInReparto(repartiId[i]);

                    foreach (MacchinaDTO MacchinaNelReparto in MacchineNelReparto)
                    {

                        if (MacchinaNelReparto.StatoId == 1)
                        {
                            countStati[0] = countStati[0] + 1;
                        }
                        if (MacchinaNelReparto.StatoId == 2)
                        {
                            countStati[1] = countStati[1] + 1;
                        }
                        if (MacchinaNelReparto.StatoId == 3)
                        {
                            countStati[2] = countStati[2] + 1;
                        }
                        if (MacchinaNelReparto.StatoId == 4)
                        {
                            countStati[3] = countStati[3] + 1;
                        }
                    }
                }
                
                return countStati;
            }
        }
        public static List<StabilimentoDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<StabilimentoDTO> lista = new List<StabilimentoDTO>();
                context.Stabilimentos.ToList().ForEach(x => lista.Add(mapper.MapStabilimentoToDTO(x)));
                return lista;
            }
        }

        public static bool Update(StabilimentoDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Stabilimento output = context.Stabilimentos.SingleOrDefault(x => x.StabilimentoId == input.StabilimentoId);
                if (output != null)
                {
                    output.Nome = input.Nome;
                    output.Citta = input.Citta;
                }
                return context.SaveChanges() > 0;
            }
        }

        public static bool Delete(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Stabilimentos.Remove(context.Stabilimentos.Find(id));
                return context.SaveChanges() > 0;
            }
        }
    }
}
