﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class StatoManager
    {
        static DataMapper mapper = new DataMapper();
        public static bool Add(StatoDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Statos.Add(mapper.MapDTOToStato(input));
                return context.SaveChanges() > 0;
            }
        }

        public static StatoDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Stato stato = context.Statos.Find(id);
                if (stato != null)
                {
                    return mapper.MapStatoToDTO(stato);
                }
                return null;
            }
        }

        public static List<StatoDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<StatoDTO> lista = new List<StatoDTO>();
                context.Statos.ToList().ForEach(x => lista.Add(mapper.MapStatoToDTO(x)));
                return lista;
            }
        }

        public static bool Update(StatoDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Stato output = context.Statos.SingleOrDefault(x => x.StatoId == input.StatoId);
                if (output != null)
                {
                    output.Stato1 = input.Stato;
                }
                return context.SaveChanges() > 0;
            }
        }

        public static bool Delete(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Statos.Remove(context.Statos.Find(id));
                return context.SaveChanges() > 0;
            }
        }
    }
}
