﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using PWluglio.Mapper;
namespace PWluglio.Manager
{
    public class AnagrafeManager
    {
        static DataMapper mapper = new DataMapper();
        public static bool Add(AnagrafeDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Anagraves.Add(mapper.MapDTOToAnagrafe(input));
                return context.SaveChanges() > 0;
            }
        }

        public static AnagrafeDTO GetSingle(decimal id)
        {
            using(TesarDBContext context=new TesarDBContext())
            {
                Anagrafe anagrafe=context.Anagraves.Find(id);
                if(anagrafe!=null)
                {
                    return mapper.MapAnagrafeToDTO(anagrafe);
                }
                return null;
            }
        }

        public static List<AnagrafeDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<AnagrafeDTO> lista = new List<AnagrafeDTO>();
                context.Anagraves.ToList().ForEach(x=>lista.Add(mapper.MapAnagrafeToDTO(x)));
                return lista;
            }
        }

        public static bool Update(AnagrafeDTO input)
        {
            using(TesarDBContext context=new TesarDBContext())
            {
                Anagrafe output = context.Anagraves.SingleOrDefault(x=>x.Id==input.Id);
                    if (output != null)
                    {
                        output.Nome = input.Nome;
                        output.Cognome = input.Cognome;
                        output.DataNascita = input.DataNascita;
                    }
                    return context.SaveChanges() > 0;
            }
        }

        public static bool Delete (decimal id)
        {
            using(TesarDBContext context=new TesarDBContext())
            {
                context.Anagraves.Remove(context.Anagraves.Find(id));
                return context.SaveChanges()>0;
            }
        }
    }
}
