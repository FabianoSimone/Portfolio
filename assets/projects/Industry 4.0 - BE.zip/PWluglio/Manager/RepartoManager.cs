﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class RepartoManager
    {
        static DataMapper mapper = new DataMapper();
        public static bool Add(RepartoDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Repartos.Add(mapper.MapDTOToReparto(input));
                return context.SaveChanges() > 0;
            }
        }
        public static string GetMappa(decimal repartoId)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                string mappa = context.Repartos.Find(repartoId).Mappa;
                if (mappa != null)
                {
                    return mappa;
                }
                return null;
            }
        }
       
        public static RepartoDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Reparto reparto = context.Repartos.Find(id);
                if (reparto != null)
                {
                    return mapper.MapRepartoToDTO(reparto);
                }
                return null;
            }
        }
        public static List<RepartoDTO> GetDepartimentInfos(decimal stabilimentoId)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Controlla();
                return context.Repartos.Where(x => x.StabilimentoId == stabilimentoId).Select(x => new RepartoDTO()
                {
                    RepartoId = x.RepartoId,
                    CoordinateX = CoordinatumManager.GetSingleReparto(x.RepartoId).CoordinateX,
                    CoordinateY = CoordinatumManager.GetSingleReparto(x.RepartoId).CoordinateY,
                    NomeReparto = x.NomeReparto,
                    Mappa = x.Mappa,
                    ResponsabileId = x.ResponsabileId,
                    NomeResponsabile = AnagrafeManager.GetSingle(OperatoreManager.GetSingle(x.ResponsabileId).AnagrafeId).Nome,
                    CognomeResponsabile = AnagrafeManager.GetSingle(OperatoreManager.GetSingle(x.ResponsabileId).AnagrafeId).Cognome,
                    Cancellato=x.Cancellato,
                    StabilimentoId=x.StabilimentoId,
                    statoReparto = GetStatoReparto(x.RepartoId)
                }).ToList();

            }
        }
        public static List<RepartoDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Controlla();
                List<RepartoDTO> lista = new List<RepartoDTO>();
                context.Repartos.ToList().ForEach(x => lista.Add(new RepartoDTO()
                {
                    RepartoId = x.RepartoId,
                    NomeReparto = x.NomeReparto,
                    CoordinateX = CoordinatumManager.GetSingleReparto(x.RepartoId).CoordinateX,
                    CoordinateY = CoordinatumManager.GetSingleReparto(x.RepartoId).CoordinateY,
                    Mappa = x.Mappa,
                    ResponsabileId = x.ResponsabileId,
                    StabilimentoId=x.StabilimentoId,
                    Cancellato=x.Cancellato,
                    NomeResponsabile = AnagrafeManager.GetSingle(OperatoreManager.GetSingle(x.ResponsabileId).AnagrafeId).Nome,
                    CognomeResponsabile = AnagrafeManager.GetSingle(OperatoreManager.GetSingle(x.ResponsabileId).AnagrafeId).Cognome,
                    statoReparto = GetStatoReparto(x.RepartoId),
                    Macchinas = MacchinaManager.GetAllInReparto(x.RepartoId)
                }));

                return lista;
                /* List<RepartoDTO> lista = new List<RepartoDTO>();

                  context.Repartos.ToList().ForEach(x => lista.Add(mapper.MapRepartoToDTO(x)));
                 return lista;*/

            }
        }

        public static int GetStatoReparto(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                int[] countStati = GetCountStatiReparto(id);
                for (int i = countStati.Length - 1; i >= 0; i--)
                {
                    if (countStati[i] != 0)
                    {
                        return i + 1;
                    }
                }
                return 1;
            }
        }
        public static int[] GetCountStatiReparto(decimal id)//Restituisce il count delle macchine nei vari stati
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<Macchina> Macchine = context.Macchinas.ToList().FindAll(x => x.RepartoId == id);
                int[] countStati = new int[4];
                foreach (Macchina Macchina in Macchine)
                {
                    if (Macchina.StatoId == 1)
                    {
                        countStati[0] = countStati[0] + 1;
                    }
                    if (Macchina.StatoId == 2)
                    {
                        countStati[1] = countStati[1] + 1;
                    }
                    if (Macchina.StatoId == 3)
                    {
                        countStati[2] = countStati[2] + 1;
                    }
                    if (Macchina.StatoId == 4)
                    {
                        countStati[3] = countStati[3] + 1;
                    }
                }
                return countStati;
            }
        }

        public static bool SpecialUpdate(decimal stabilimentoId,decimal repartoId, bool cancellato)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Reparto output = context.Repartos.SingleOrDefault(x => x.RepartoId == repartoId && x.StabilimentoId==stabilimentoId);
                if (output != null)
                {
                    output.Cancellato = cancellato;
                }
                return context.SaveChanges() > 0;
            }
        }
        public static bool Update(RepartoDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Reparto output = context.Repartos.SingleOrDefault(x => x.RepartoId == input.RepartoId);
                if (output != null)
                {
                    output.NomeReparto = input.NomeReparto.ToUpper();
                    output.ResponsabileId = input.ResponsabileId;
                    output.StabilimentoId = input.StabilimentoId;
                    output.Mappa = input.Mappa;
                    output.Cancellato = input.Cancellato;
             
                }
                return context.SaveChanges() > 0;
            }
        }

        public static bool Delete(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Repartos.Remove(context.Repartos.Find(id));
                return context.SaveChanges() > 0;
            }
        }

        public static void Controlla()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<Reparto> reparti = context.Repartos.ToList();
                foreach (Reparto Rep in reparti)
                {
                    if (context.Coordinata.ToList().Count(x => x.RepartoId == Rep.RepartoId) == 0)
                    {
                        CoordinatumManager.Add(new CoordinatumDTO()
                        {
                            Id = 0,
                            Reparto = mapper.MapRepartoToDTO(Rep),
                            Stabilimento = StabilimentoManager.GetSingle(Rep.StabilimentoId),
                            RepartoId = Rep.RepartoId,
                            CoordinateX = 600,
                            CoordinateY = 600
                        });
                    }
                }
            }
        }

    }
}
