﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class UserManager
    {
        static DataMapper mapper = new DataMapper();
        public static bool Add(UserDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                SHA256 shaM = new SHA256Managed();
                input.Password=Encoding.Default.GetString(shaM.ComputeHash(Encoding.ASCII.GetBytes(input.Password)));
                context.Users.Add(mapper.MapDTOToUser(input));
                return context.SaveChanges() > 0;
            }
        }
        public static UserDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                User user = context.Users.Find(id);
                if (user != null)
                {
                    return mapper.MapUserToDTO(user);
                }
                return null;
            }
        }

        public static List<UserDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<UserDTO> lista = new List<UserDTO>();
                context.Users.ToList().ForEach(x => lista.Add(mapper.MapUserToDTO(x)));
                return lista;
            }
        }

        public static bool Update(UserDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                User output = context.Users.SingleOrDefault(x => x.Id == input.Id);
                if (output != null)
                {
                    output.Username = input.UserName;
                    output.Password = input.Password;
                    output.Email = input.Email;
                    output.Admin = input.Admin;
                }
                return context.SaveChanges() > 0;
            }
        }

        public static bool Delete(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Users.Remove(context.Users.Find(id));
                return context.SaveChanges() > 0;
            }
        }
    }
}
