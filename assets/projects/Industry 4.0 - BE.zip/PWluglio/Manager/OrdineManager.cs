﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class OrdineManager
    {
        static DataMapper mapper = new DataMapper();
        public static bool Add(OrdineDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Ordines.Add(mapper.MapDTOToOrdine(input));
                return context.SaveChanges() > 0;
            }
        }

        public static OrdineDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Ordine ordine = context.Ordines.Find(id);
                if (ordine != null)
                {
                    return mapper.MapOrdineToDTO(ordine);
                }
                return null;
            }
        }

        public static List<OrdineDTO> GetSingleMacchina(decimal macchinaid)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<OrdineDTO> ordiniConArticolo = new List<OrdineDTO>();
                context.Ordines.ToList().FindAll(x => x.MacchinaId == macchinaid).ForEach(x => ordiniConArticolo.Add(new OrdineDTO()
                {
                    ArticoloId=x.ArticoloId,
                    Data=x.Data,
                    MacchinaId=x.MacchinaId,
                    Quantita=x.Quantita,
                    OrdineId=x.OrdineId,
                    Articolo= ArticoloManager.GetSingle(x.ArticoloId)
                }));
                return ordiniConArticolo;
                // return context.Ordines.ToList().FindAll(x => x.MacchinaId == macchinaid).ConvertAll(new Converter<Ordine, OrdineDTO>(ConvertOrdineToOrdineDTO));
            }
        }
      
        public static List<OrdineDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<OrdineDTO> lista = new List<OrdineDTO>();
                context.Ordines.ToList().ForEach(x => lista.Add(mapper.MapOrdineToDTO(x)));
                return lista;
            }
        }
        public static List<OrdineDTO> GetAllArticolo(decimal articoloId)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                return context.Ordines.ToList().FindAll(x=>x.ArticoloId==articoloId).ConvertAll(new Converter<Ordine, OrdineDTO>(ConvertOrdineToOrdineDTO));
            }
        }


        public static bool Update(OrdineDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Ordine output = context.Ordines.SingleOrDefault(x => x.OrdineId == input.OrdineId);
                if (output != null)
                {
                    output.Quantita = input.Quantita;
                    output.ArticoloId = input.ArticoloId;
                    output.MacchinaId = input.MacchinaId;
                }
                return context.SaveChanges() > 0;
            }
        }

        public static bool Delete(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Ordines.Remove(context.Ordines.Find(id));
                return context.SaveChanges() > 0;
            }
        }

        public static OrdineDTO ConvertOrdineToOrdineDTO(Ordine input)
        {
            return mapper.MapOrdineToDTO(input);
        }
    }
}
