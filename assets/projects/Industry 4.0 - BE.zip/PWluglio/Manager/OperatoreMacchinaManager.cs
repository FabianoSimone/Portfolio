﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class OperatoreMacchinaManager
    {
        static DataMapper mapper = new DataMapper();
        /*
        public static bool Add(OperatoreMacchinaDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.OperatoreMacchinas.Add(mapper.MapDTOToOperatoreMacchina(input));
                return context.SaveChanges() > 0;
            }
        }
        */

        public static OperatoreMacchinaDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                OperatoreMacchina operatoremacchina = context.OperatoreMacchinas.Find(id);
                if (operatoremacchina != null)
                {
                    return mapper.MapOperatoreMacchinaToDTO(operatoremacchina);
                }
                return null;
            }
        }

        public static List<OperatoreMacchinaDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<OperatoreMacchinaDTO> lista = new List<OperatoreMacchinaDTO>();
                context.OperatoreMacchinas.ToList().ForEach(x => lista.Add(mapper.MapOperatoreMacchinaToDTO(x)));
                return lista;
            }
        }
        public static List<OperatoreMacchinaDTO> GetSingleAllMacchina(decimal macchinaId)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<OperatoreMacchinaDTO> lista = new List<OperatoreMacchinaDTO>();
                context.OperatoreMacchinas.ToList().FindAll(x => x.MacchinaId == macchinaId).ForEach(x => lista.Add(new OperatoreMacchinaDTO()
                {
                    MacchinaId=x.MacchinaId,
                    OperatoreId=x.OperatoreId,
                    NomeOperatore=AnagrafeManager.GetSingle(OperatoreManager.GetSingle(x.OperatoreId).AnagrafeId).Nome,
                    CognomeOperatore= AnagrafeManager.GetSingle(OperatoreManager.GetSingle(x.OperatoreId).AnagrafeId).Cognome

                }));
                return lista;
            }
        }
        public static List<OperatoreMacchinaDTO> GetSingleAllOperatore(decimal operatoreId)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<OperatoreMacchinaDTO> lista = new List<OperatoreMacchinaDTO>();
                context.OperatoreMacchinas.ToList().FindAll(x => x.OperatoreId == operatoreId).ForEach(x => lista.Add(mapper.MapOperatoreMacchinaToDTO(x)));
                return lista;
            }
        }
    }
}
