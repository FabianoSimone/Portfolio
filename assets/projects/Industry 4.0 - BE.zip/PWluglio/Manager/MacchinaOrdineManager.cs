﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class MacchinaOrdineManager
    {
        static DataMapper mapper = new DataMapper();
        /*
        public static bool Add(MacchinaOrdineDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.MacchinaOrdines.Add(mapper.MapDTOToMacchinaOrdine(input));
                return context.SaveChanges() > 0;
            }
        }
        */

        public static MacchinaOrdineDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                MacchinaOrdine macchinaordine = context.MacchinaOrdines.Find(id);
                if (macchinaordine != null)
                {
                    return mapper.MapMacchinaOrdineToDTO(context.MacchinaOrdines.Find(id));
                }
                return null;
            }
        }

        public static List<MacchinaOrdineDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<MacchinaOrdineDTO> lista = new List<MacchinaOrdineDTO>();
                context.MacchinaOrdines.ToList().ForEach(x => lista.Add(mapper.MapMacchinaOrdineToDTO(x)));
                return lista;
            }
        }

        public static List<MacchinaOrdineDTO> GetSingleAllMacchina(decimal macchinaId)
        {
            using(TesarDBContext context=new TesarDBContext())
            {
                List<MacchinaOrdineDTO> lista = new List<MacchinaOrdineDTO>();
                context.MacchinaOrdines.ToList().FindAll(x => x.MacchinaId == macchinaId).ForEach(x => lista.Add(mapper.MapMacchinaOrdineToDTO(x)));
                return lista;
            }
        }
        public static List<MacchinaOrdineDTO> GetSingleAllOrdine(decimal ordineId)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<MacchinaOrdineDTO> lista = new List<MacchinaOrdineDTO>();
                context.MacchinaOrdines.ToList().FindAll(x => x.OrdineId == ordineId).ForEach(x => lista.Add(mapper.MapMacchinaOrdineToDTO(x)));
                return lista;
            }
        }
    }
}
