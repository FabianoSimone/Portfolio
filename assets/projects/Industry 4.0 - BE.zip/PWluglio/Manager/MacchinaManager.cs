﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class MacchinaManager
    {
        static DataMapper mapper = new DataMapper();
        public static bool Add(MacchinaDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Macchinas.Add(mapper.MapDTOToMacchina(input));
                return context.SaveChanges() > 0;
            }
        }

        public static MacchinaDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Macchina macchina=context.Macchinas.Find(id);
                if(macchina!=null)
                {
                    return mapper.MapMacchinaToDTO(macchina);
                }
                return null;
            }
        }
        public static bool SpecialUpdate(decimal repartoId, decimal macchinaId, bool cancellato)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Macchina output = context.Macchinas.SingleOrDefault(x => x.MacchinaId==macchinaId && x.RepartoId == repartoId);
                if (output != null)
                {
                    output.Cancellato = cancellato;
                }
                return context.SaveChanges() > 0;
            }
        }
        public static List<MacchinaDTO> GetDepartimentInfos(decimal repartoId)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                var all = context.Macchinas.Where(x => x.RepartoId == repartoId).Select(x => new MacchinaDTO()
                {
                    RepartoId = x.RepartoId,
                    CoordinateX = CoordinatumManager.GetSingleMacchina(x.MacchinaId).CoordinateX,
                    CoordinateY = CoordinatumManager.GetSingleMacchina(x.MacchinaId).CoordinateY,
                    StatoId=x.StatoId,
                    MacchinaId=x.MacchinaId,
                    Cancellato=x.Cancellato,
                    Nome=x.Nome
                    
                }).ToList();

                return all;

            }
        }
        public static List<MacchinaDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<MacchinaDTO> lista = new List<MacchinaDTO>();
                context.Macchinas.ToList().ForEach(x => lista.Add(mapper.MapMacchinaToDTO(x)));
                return lista;
            }
        }

        
        public static List<MacchinaDTO> GetAllInReparto(decimal repartoId) // Tutte le macchine di un reparto
        {
            using(TesarDBContext context= new TesarDBContext())
            {
                return context.Macchinas.ToList().FindAll(x => x.RepartoId == repartoId)
                    .ConvertAll(new Converter<Macchina, MacchinaDTO>(MacchinaToMacchinaDTO));
            }
        }
        public static bool Update(MacchinaDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Macchina output = context.Macchinas.SingleOrDefault(x => x.MacchinaId == input.MacchinaId);
                if (output != null)
                {
                    output.Nome = input.Nome;
                    output.Tipolavorazione = input.Tipolavorazione;
                    output.Quantitaprodotta = input.Quantitaprodotta;
                    output.RepartoId = input.RepartoId;
                    output.StatoId = output.StatoId;
                }
                return context.SaveChanges() > 0;
            }
        }

        public static bool Delete(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Macchinas.Remove(context.Macchinas.Find(id));
                return context.SaveChanges() > 0;
            }
        }

        public static MacchinaDTO MacchinaToMacchinaDTO (Macchina mac)
        {
            return mapper.MapMacchinaToDTO(mac);
        }

    }
}