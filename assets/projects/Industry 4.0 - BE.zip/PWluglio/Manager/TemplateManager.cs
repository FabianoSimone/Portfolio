﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class TemplateManager
    {
        static DataMapper mapper = new DataMapper();
        public static bool Add(TemplateDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Templates.Add(mapper.MapDTOToTemplate(input));
                return context.SaveChanges() > 0;
            }
        }

        public static TemplateDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Template template= context.Templates.Find(id);
                if (template != null)
                {
                    return mapper.MapTemplateToDTO(template);
                }
                return null;
            }
        }

        public static List<TemplateDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<TemplateDTO> lista = new List<TemplateDTO>();
                context.Templates.ToList().ForEach(x => lista.Add(mapper.MapTemplateToDTO(x)));
                return lista;
            }
        }

        public static bool Update(TemplateDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Template output = context.Templates.SingleOrDefault(x => x.TemplateId == input.TemplateId);
                if (output != null)
                {
                    output.Html = input.Html;
                    output.RepartoId = input.RepartoId;
                    output.StabilimentoId = input.StabilimentoId;
                }
                return context.SaveChanges() > 0;
            }
        }

        public static bool Delete(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Templates.Remove(context.Templates.Find(id));
                return context.SaveChanges() > 0;
            }
        }
    }
}
