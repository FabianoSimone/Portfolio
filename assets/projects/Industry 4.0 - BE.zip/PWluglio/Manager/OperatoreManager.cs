﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class OperatoreManager
    {
        static DataMapper mapper = new DataMapper();
        public static bool Add(OperatoreDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Operatores.Add(mapper.MapDTOToOperatore(input));
                return context.SaveChanges() > 0;
            }
        }

        public static OperatoreDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Operatore operatore = context.Operatores.Find(id);
                if (operatore != null)
                {
                    return mapper.MapOperatoreToDTO(context.Operatores.Find(id));
                }
                return null;
            }
        }
        public static string GetMappa(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Operatore mappa = context.Operatores.Single(x => x.OperatorId == id);
                if (mappa.Immagine != null)
                {
                    return mappa.Immagine;
                }
                return null;
            }
        }

        public static List<OperatoreDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<OperatoreDTO> lista = new List<OperatoreDTO>();
                context.Operatores.ToList().ForEach(x => lista.Add(mapper.MapOperatoreToDTO(x)));
                return lista;
            }
        }

        public static bool Update(OperatoreDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Operatore output = context.Operatores.SingleOrDefault(x => x.OperatorId == input.OperatorId);
                if (output != null)
                {
                    output.Ruolo = input.Ruolo;
                    output.AnagrafeId = input.AnagrafeId;
                    output.Immagine = input.Immagine;
                }
                return context.SaveChanges() > 0;
            }
        }

        public static bool Delete(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Operatores.Remove(context.Operatores.Find(id));
                return context.SaveChanges() > 0;
            }
        }
    }
}
