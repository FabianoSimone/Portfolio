﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class MacchinaErroreManager
    {
        static DataMapper mapper = new DataMapper();

        /*
        public static bool Add(MacchinaErroreDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.MacchinaErrores.Add(mapper.MapDTOToMacchinaErrore(input));
                return context.SaveChanges() > 0;
            }
        }

        */

        public static MacchinaErroreDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                MacchinaErrore macchinaerrore = context.MacchinaErrores.Find(id);
                if (macchinaerrore != null)
                {
                    return mapper.MapMacchinaErroreToDTO(context.MacchinaErrores.Find(id));
                }
                return null;
            }
        }

        public static List<MacchinaErroreDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<MacchinaErroreDTO> lista = new List<MacchinaErroreDTO>();
                context.MacchinaErrores.ToList().ForEach(x => lista.Add(mapper.MapMacchinaErroreToDTO(x)));
                return lista;
            }
        }
        public static List<MacchinaErroreDTO> GetSingleAllMacchina(decimal macchinaId)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<MacchinaErroreDTO> lista = new List<MacchinaErroreDTO>();
                context.MacchinaErrores.ToList().FindAll(x => x.MacchinaId == macchinaId).ForEach(x => lista.Add(new MacchinaErroreDTO()
                {
                    MacchinaId = x.MacchinaId,
                    Data = x.Data,
                    ErroreId = x.ErroreId,
                    NomeMacchina =MacchinaManager.GetSingle(x.MacchinaId).Nome,
                    Priorita=x.Priorita,
                    Risolto=x.Risolto,
                    DescrizioneErrore=ErroreManager.GetSingle(x.ErroreId).Descizione,
                    TipoErrore=ErroreManager.GetSingle(x.ErroreId).Tipo,
                    RepartoId=MacchinaManager.GetSingle(x.MacchinaId).RepartoId
                }));
                return lista;
            }
        }
        public static List<MacchinaErroreDTO> GetSingleAllErrore(decimal erroreId)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<MacchinaErroreDTO> lista = new List<MacchinaErroreDTO>();
                context.MacchinaErrores.ToList().FindAll(x => x.ErroreId == erroreId).ForEach(x => lista.Add(mapper.MapMacchinaErroreToDTO(x)));
                return lista;
            }
        }
    }
}
