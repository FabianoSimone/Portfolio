﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class ArticoloManager
    {
        static DataMapper mapper = new DataMapper();
        public static bool Add(ArticoloDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Articolos.Add(mapper.MapDTOToArticolo(input));
                return context.SaveChanges()>0;
            }
        }

        public static ArticoloDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
               Articolo articolo=context.Articolos.Find(id);
                if(articolo!=null)
                {
                    return mapper.MapArticoloToDTO(articolo);
                }
                return null;
            }
        }

        public static List<ArticoloDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<ArticoloDTO> lista = new List<ArticoloDTO>();
                context.Articolos.ToList().ForEach(x => lista.Add(new ArticoloDTO()
                {
                    ArticoloId=x.ArticoloId,
                    Materiale=x.Materiale,
                    Nome=x.Nome,
                    Peso=x.Peso,
                    Ordines=OrdineManager.GetAllArticolo(x.ArticoloId)
                }));
                return lista;
            }
        }

        public static bool Update(ArticoloDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Articolo output = context.Articolos.SingleOrDefault(x => x.ArticoloId == input.ArticoloId);
                if (output != null)
                {
                    output.Materiale = input.Materiale;
                    output.Nome = input.Nome;
                    output.Peso = input.Peso;
                }
                return context.SaveChanges() > 0;
            }
        }

        public static bool Delete(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Articolos.Remove(context.Articolos.Find(id));
                return context.SaveChanges() > 0;
            }
        }

    }
}
