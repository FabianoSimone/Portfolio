﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class CoordinatumManager
    {
        static DataMapper mapper = new DataMapper();
        public static bool Add(CoordinatumDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                int c=GetAll().Count(x =>  x.RepartoId == input.RepartoId);
                int m = GetAll().Count(x => x.MacchinaId == input.MacchinaId);
                if (c == 0 && input.MacchinaId==null || m == 0 && input.RepartoId == null)
                {
                    context.Coordinata.Add(mapper.MapDTOToCoordinatum(input));
                }
                if ( c!=0 && input.MacchinaId == null )
                {
                    Coordinatum t=context.Coordinata.SingleOrDefault(x => x.RepartoId == input.RepartoId);
                    input.Id = t.Id;
                    return Update(input);
                }
                if (m != 0 && input.RepartoId == null)
                {
                    Coordinatum t = context.Coordinata.SingleOrDefault(x => x.MacchinaId == input.MacchinaId);
                    input.Id = t.Id;
                    return SpecialUpdate(input);
                }

                return context.SaveChanges() > 0;
            }
        }
        public static bool AddCoordinataMacchina(CoordinatumDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                int c = GetAll().Count(x => x.MacchinaId == input.MacchinaId);
                if (c == 0 && input.RepartoId == null)
                {
                    context.Coordinata.Add(mapper.MapDTOToCoordinatum(input));
                }
                if (c != 0 && input.RepartoId == null)
                {
                    Coordinatum t = context.Coordinata.SingleOrDefault(x => x.MacchinaId == input.MacchinaId);
                    input.Id = t.Id;
                    return SpecialUpdate(input);
                }
                return context.SaveChanges() > 0;
            }
        }

        public static CoordinatumDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
               Coordinatum coor=context.Coordinata.Find(id);
                if(coor!=null)
                {
                    return mapper.MapCoordinatumToDTO(coor);
                }
                return null;
            }
        }
        public static CoordinatumDTO GetSingleReparto(decimal repartoId)
        {
            using(TesarDBContext context=new TesarDBContext())
            {
                Coordinatum coordinata = context.Coordinata.ToList().Find(x => x.RepartoId == repartoId);
                if (coordinata!=null)
                {
                    return mapper.MapCoordinatumToDTO(coordinata);
                }
                return null;
            }
        }
        public static CoordinatumDTO GetSingleMacchina(decimal macchinaId)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Coordinatum coordinata = context.Coordinata.ToList().Find(x => x.MacchinaId == macchinaId);
                if (coordinata != null)
                {
                    return mapper.MapCoordinatumToDTO(coordinata);
                }
                return null;
            }
        }

        public static List<CoordinatumDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<CoordinatumDTO> lista = new List<CoordinatumDTO>();
                context.Coordinata.ToList().ForEach(x => lista.Add(mapper.MapCoordinatumToDTO(x)));
                return lista;
            }
        }

        public static bool SpecialUpdate(CoordinatumDTO input)
        {
            using(TesarDBContext context=new TesarDBContext())
            {
                Coordinatum output = context.Coordinata.SingleOrDefault(x => x.MacchinaId == input.MacchinaId);
                if (output != null)
                {
                    output.CoordinateX = input.CoordinateX;
                    output.CoordinateY = input.CoordinateY;
                }
                return context.SaveChanges() > 0;
            }
        }
        public static bool Update(CoordinatumDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Coordinatum output = context.Coordinata.SingleOrDefault(x => x.RepartoId == input.RepartoId);
                if (output != null)
                {
                    output.CoordinateX = input.CoordinateX;
                    output.CoordinateY = input.CoordinateY;
                }
                return context.SaveChanges() > 0;
            }
        }

        public static bool Delete(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Coordinata.Remove(context.Coordinata.Find(id));
                return context.SaveChanges() > 0;
            }
        }
    }
}
