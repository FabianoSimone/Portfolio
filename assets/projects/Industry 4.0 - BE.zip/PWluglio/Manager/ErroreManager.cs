﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using PWluglio.Mapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Manager
{
    public class ErroreManager
    {
        static DataMapper mapper = new DataMapper();
        public static bool Add(ErroreDTO input)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                context.Errores.Add(mapper.MapDTOToErrore(input));
                return context.SaveChanges() > 0;
            }
        }

        public static ErroreDTO GetSingle(decimal id)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                Errore errore = context.Errores.Find(id);
                if (errore != null)
                {
                    return mapper.MapErroreToDTO(errore);
                }
                return null;
            }
        }

        public static List<ErroreDTO> GetAll()
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<ErroreDTO> lista = new List<ErroreDTO>();
                context.Errores.ToList().ForEach(x => lista.Add(mapper.MapErroreToDTO(x)));
                return lista;
            }
        }
        public static List<MacchinaErroreDTO> GetAllinReparto(decimal repartoId)
        {
            using (TesarDBContext context = new TesarDBContext())
            {
                List<MacchinaErroreDTO> lista = new List<MacchinaErroreDTO>();
                List<MacchinaDTO> macchineinReparto = MacchinaManager.GetAllInReparto(repartoId);
                List<MacchinaErrore> macchineErrori = new List<MacchinaErrore>();
                foreach (MacchinaDTO macchina in macchineinReparto)
                {
                    context.MacchinaErrores.ToList().FindAll(x => x.MacchinaId == macchina.MacchinaId && x.Risolto == false).ForEach(x => macchineErrori.Add(x));
                }
                macchineErrori.ForEach(x => lista.Add(new MacchinaErroreDTO()
                {
                    MacchinaId = x.MacchinaId,
                    NomeMacchina = MacchinaManager.GetSingle(x.MacchinaId).Nome,
                    DescrizioneErrore = GetSingle(x.ErroreId).Descizione,
                    RepartoId = repartoId,
                    TipoErrore = GetSingle(x.ErroreId).Tipo
                }));

                return lista;
            }
        }

    }
}
