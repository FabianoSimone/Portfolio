﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PWluglio.DTO;
using PWluglio.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class RepartoController : ControllerBase
    {
        [HttpPost, Route("Create")]
        public IActionResult Create(RepartoDTO input)
        {
            try
            {
                if (RepartoManager.Add(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetSingle/{id}")]
        public IActionResult GetSingle(decimal id)
        {
            try
            {
                if (RepartoManager.GetSingle(id) != null)
                {
                    return Ok(RepartoManager.GetSingle(id));
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetMappa/{repartoId}")]
        public IActionResult GetMappa(decimal repartoId)
        {
            try
            {
                if (RepartoManager.GetMappa(repartoId) != null)
                {
                    return Ok(RepartoManager.GetMappa(repartoId));
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPut, Route("SpecialUpdate/{stabilimentoId}/{repartoId}/{cancellato}")]
        public IActionResult SpecialUpdate(decimal stabilimentoId, decimal repartoId, bool cancellato)
        {
            try
            {
                return Ok(RepartoManager.SpecialUpdate(stabilimentoId, repartoId, cancellato));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetDepartimentInfos/{stabilimentoId}")]
        public IActionResult GetDepartimentInfos(decimal stabilimentoId)
        {
            try
            {
                return Ok(RepartoManager.GetDepartimentInfos(stabilimentoId));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetAll")]
        public IActionResult GetAll()
        {
            try
            {
                return Ok(RepartoManager.GetAll());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetStatoReparto/{repartoId}")]
        public IActionResult GetStatoReparto(decimal repartoId)
        {
            try
            {
                return Ok(RepartoManager.GetStatoReparto(repartoId));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetCountStatiReparto/{repartoId}")]
        public IActionResult GetCountStatiReparto(decimal repartoId)
        {
            try
            {
                return Ok(RepartoManager.GetCountStatiReparto(repartoId));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPut, Route("Update")]
        public IActionResult Update(RepartoDTO input)
        {
            try
            {
                if (RepartoManager.Update(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);

            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpDelete, Route("Delete/{id}")]
        public IActionResult Delete(decimal id)
        {
            try
            {
                if (RepartoManager.Delete(id))
                {
                    return Ok();
                }
                return BadRequest(id);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
