﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PWluglio.DTO;
using PWluglio.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MacchinaErroreController : ControllerBase
    {

        /*
        [HttpPost, Route("Create")]
        public IActionResult Create(MacchinaErroreDTO input)
        {
            try
            {
                if (MacchinaErroreManager.Add(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        */
        [HttpGet, Route("GetSingle/{id}")]
        public IActionResult GetSingle(decimal id)
        {
            try
            {
                return Ok(MacchinaErroreManager.GetSingle(id));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetAll")]
        public IActionResult GetAll()
        {
            try
            {
                return Ok(MacchinaErroreManager.GetAll());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetSingleAllMacchina/{id}")]
        public IActionResult GetSingleAllMacchina(decimal id)
        {
            try
            {
                if (MacchinaErroreManager.GetSingleAllMacchina(id) != null)
                {
                    return Ok(MacchinaErroreManager.GetSingleAllMacchina(id));
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetSingleAllErrore/{id}")]
        public IActionResult GetSingleAlErrore(decimal id)
        {
            try
            {
                return Ok(MacchinaErroreManager.GetSingleAllErrore(id));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        /* [HttpPut, Route("Update")]
        public IActionResult Update(MacchinaErroreDTO input)
        {
            try
            {
                if (MacchinaErroreManager.Update(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);

            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        */

        /*
        [HttpDelete, Route("Delete/{id}")]
        public IActionResult Delete(decimal id)
        {
            try
            {
                if (MacchinaErroreManager.Delete(id))
                {
                    return Ok();
                }
                return BadRequest(id);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        */
    }
}
