﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PWluglio.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OperatoreMacchinaController : ControllerBase
    {
        /*
        [HttpPost, Route("Create")]
        public IActionResult Create(OperatoreMacchinaDTO input)
        {
            try
            {
                if (OperatoreMacchinaManager.Add(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        */
        [HttpGet, Route("GetSingle/{id}")]
        public IActionResult GetSingle(decimal id)
        {
            try
            {
                if (OperatoreMacchinaManager.GetSingle(id) != null)
                {
                    return Ok(OperatoreMacchinaManager.GetSingle(id));
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetAll")]
        public IActionResult GetAll()
        {
            try
            {
                return Ok(OperatoreMacchinaManager.GetAll());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet, Route("GetSingleAllMacchina/{id}")]
        public IActionResult GetSingleAllMacchina(decimal id)
        {
            try
            {
                return Ok(OperatoreMacchinaManager.GetSingleAllMacchina(id));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetSingleAllOperatore/{id}")]
        public IActionResult GetSingleAllOperatore(decimal id)
        {
            try
            {
                return Ok(OperatoreMacchinaManager.GetSingleAllOperatore(id));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        /* [HttpPut, Route("Update")]
        public IActionResult Update(OperatoreMacchinaDTO input)
        {
            try
            {
                if (OperatoreMacchinaManager.Update(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);

            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        */

        /*
        [HttpDelete, Route("Delete/{id}")]
        public IActionResult Delete(decimal id)
        {
            try
            {
                if (OperatoreMacchinaManager.Delete(id))
                {
                    return Ok();
                }
                return BadRequest(id);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        */
    }
}
