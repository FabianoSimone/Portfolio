﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PWluglio.DTO;
using PWluglio.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ErroreController : ControllerBase
    {
        [HttpPost, Route("Create")]
        public IActionResult Create(ErroreDTO input)
        {
            try
            {
                if (ErroreManager.Add(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetSingle/{id}")]
        public IActionResult GetSingle(decimal id)
        {
            try
            {
                if (ErroreManager.GetSingle(id)!=null)
                {
                    return Ok(ErroreManager.GetSingle(id));
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);

            }
        }
        [HttpGet, Route("GetAllinReparto/{repartoId}")]
        public IActionResult GetAllinReparto(decimal repartoId)
        {
            try
            {
              
                    return Ok(ErroreManager.GetAllinReparto(repartoId));

            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetAll")]
        public IActionResult GetAll()
        {
            try
            {
                return Ok(ErroreManager.GetAll());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        }
    }

