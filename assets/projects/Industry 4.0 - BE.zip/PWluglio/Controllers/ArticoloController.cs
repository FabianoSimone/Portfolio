﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PWluglio.DTO;
using PWluglio.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ArticoloController : ControllerBase
    {
        [HttpPost, Route("Create")]
        public IActionResult Create(ArticoloDTO input)
        {
            try
            {
                if (ArticoloManager.Add(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetSingle/{id}")]
        public IActionResult GetSingle(decimal id)
        {
            try
            {
                if (ArticoloManager.GetSingle(id) != null)
                {
                    return Ok(ArticoloManager.GetSingle(id));
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetAll")]
        public IActionResult GetAll()
        {
            try
            {
                return Ok(ArticoloManager.GetAll());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPut, Route("Update")]
        public IActionResult Update(ArticoloDTO input)
        {
            try
            {
                if (ArticoloManager.Update(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);

            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpDelete, Route("Delete/{id}")]
        public IActionResult Delete(decimal id)
        {
            try
            {
                if (ArticoloManager.Delete(id))
                {
                    return Ok();
                }
                return BadRequest(id);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}