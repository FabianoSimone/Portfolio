﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using PWluglio.DAL.Entities;
using PWluglio.DTO;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Security.Claims;
using System.Text;
using System.Threading.Tasks;

namespace PWluglio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticationController : ControllerBase
    {
        private readonly UserManager<User> _userManager;
        private readonly IConfiguration _configuration;
        public AuthenticationController(UserManager<User> userManager, IConfiguration configuration)
        {
            _userManager = userManager;
            _configuration = configuration;
        }

        [HttpPost, Route("Login")]
        public async Task<IActionResult> Login(LoginDTO model)
        {
            var user = await _userManager.FindByNameAsync(model.Username);
            if (user != null && await _userManager.CheckPasswordAsync(user, model.Password))
            {
                List<Claim> AuthClaim = new List<Claim>()
                {
                    new Claim(ClaimTypes.Name, user.Username),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
                };
                var userRoles = await _userManager.GetRolesAsync(user);
                foreach (string role in userRoles)
                    AuthClaim.Add(new Claim(ClaimTypes.Role, role));
                SymmetricSecurityKey securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JWT:Secret"]));
                JwtSecurityToken token = new JwtSecurityToken
                    (
                      issuer: _configuration["JWT:ValidIssuer"],
                        audience: _configuration["JWT:ValidAudience"],
                        expires: DateTime.Now.AddHours(3),
                        claims: AuthClaim,
                        signingCredentials: new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256)
                    );
                return Ok(new { token = new JwtSecurityTokenHandler().WriteToken(token), Expiration = token.ValidTo });
            }
            return Unauthorized();
        }

        [HttpPost, Route("Register")]
        public async Task<IActionResult> Register([FromBody] RegisterDTO model)
        {
            var UserExists = await _userManager.FindByNameAsync(model.Username);
            if (UserExists != null)
                return StatusCode(StatusCodes.Status500InternalServerError);
            User user = new User()
            {
                Email = model.Email,
                SecurityStamp = Guid.NewGuid().ToString(),
                Username = model.Username,
                Password = model.Password,
                Admin = model.Admin
                //Role = Roles.Basic
            };
            try
            {
                IdentityResult result = await _userManager.CreateAsync(user, model.Password);
                if (!result.Succeeded)
                    return StatusCode(StatusCodes.Status500InternalServerError);
                // await _userManager.AddToRoleAsync(user, Roles.Basic.ToString());
                return Ok();
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
        }

        [HttpDelete, Route("DeleteUser/{username}")]
        public async Task<IActionResult> DeleteUser(string username)
        {
            var actualUser = await _userManager.FindByNameAsync(username);
            try
            {
                if (actualUser != null)
                {
                    var result = await _userManager.DeleteAsync(actualUser);
                    if (result.Succeeded)
                    {
                        return Ok();
                    }
                }
            }
            catch (Exception e)
            {
                return StatusCode(StatusCodes.Status400BadRequest);
            }
            return StatusCode(StatusCodes.Status500InternalServerError);
        }

    }
}
