﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PWluglio.DTO;
using PWluglio.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdineController : ControllerBase
    {
        [HttpPost, Route("Create")]
        public IActionResult Create(OrdineDTO input)
        {
            try
            {
                if (OrdineManager.Add(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetSingle/{id}")]
        public IActionResult GetSingle(decimal id)
        {
            try
            {
                if (OrdineManager.GetSingle(id) != null)
                {
                    return Ok(OrdineManager.GetSingle(id));
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetAllArticolo/{articoloId}")]
        public IActionResult GetAllArticolo(decimal articoloId)
        {
            try
            {
                if (OrdineManager.GetAllArticolo(articoloId) != null)
                {
                    return Ok(OrdineManager.GetAllArticolo(articoloId));
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet, Route("GetSingleMacchina/{macchinaid}")]
        public IActionResult GetSingleMacchina(decimal macchinaid)
        {
            try
            {
                return Ok(OrdineManager.GetSingleMacchina(macchinaid));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }


        [HttpGet, Route("GetAll")]
        public IActionResult GetAll()
        {
            try
            {
                return Ok(OrdineManager.GetAll());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPut, Route("Update")]
        public IActionResult Update(OrdineDTO input)
        {
            try
            {
                if (OrdineManager.Update(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);

            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpDelete, Route("Delete/{id}")]
        public IActionResult Delete(decimal id)
        {
            try
            {
                if (OrdineManager.Delete(id))
                {
                    return Ok();
                }
                return BadRequest(id);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
