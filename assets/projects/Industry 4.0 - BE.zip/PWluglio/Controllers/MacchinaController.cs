﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PWluglio.DTO;
using PWluglio.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MacchinaController : ControllerBase
    {
        [HttpPost, Route("Create")]
        public IActionResult Create(MacchinaDTO input)
        {
            try
            {
                if (MacchinaManager.Add(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetSingle/{id}")]
        public IActionResult GetSingle(decimal id)
        {
            try
            {
                if (MacchinaManager.GetSingle(id) != null)
                {
                    return Ok(MacchinaManager.GetSingle(id));
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPut, Route("SpecialUpdate/{repartoId}/{macchinaId}/{cancellato}")]
        public IActionResult SpecialUpdate(decimal repartoId, decimal macchinaId, bool cancellato)
        {
            try
            {
                return Ok(MacchinaManager.SpecialUpdate(repartoId, macchinaId, cancellato));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetAll")]
        public IActionResult GetAll()
        {
            try
            {
                return Ok(MacchinaManager.GetAll());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetDepartimentInfos/{repartoId}")]
        public IActionResult GetDepartimentInfos(decimal repartoId)
        {
            try
            {
                return Ok(MacchinaManager.GetDepartimentInfos(repartoId));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetAllInReparto")]
        public IActionResult GetAllInReparto(decimal repartoId)
        {
            try
            {
                return Ok(MacchinaManager.GetAllInReparto(repartoId));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPut, Route("Update")]
        public IActionResult Update(MacchinaDTO input)
        {
            try
            {
                if (MacchinaManager.Update(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);

            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpDelete, Route("Delete/{id}")]
        public IActionResult Delete(decimal id)
        {
            try
            {
                if (MacchinaManager.Delete(id))
                {
                    return Ok();
                }
                return BadRequest(id);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
