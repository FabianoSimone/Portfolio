﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using PWluglio.DTO;
using PWluglio.Manager;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CoordinatumController : ControllerBase
    {
        [HttpPost, Route("Create")]
        public IActionResult Create(CoordinatumDTO input)
        {
            try
            {
                if (CoordinatumManager.Add(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPost, Route("AddCoordinataMacchina")]
        public IActionResult AddCoordinataMacchina(CoordinatumDTO input)
        {
            try
            {
                if (CoordinatumManager.AddCoordinataMacchina(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetSingle/{id}")]
        public IActionResult GetSingle(decimal id)
        {
            try
            {
                if (CoordinatumManager.GetSingle(id)!=null)
                {
                    return Ok(CoordinatumManager.GetSingle(id));
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetSingleReparto/{repartoid}")]
        public IActionResult GetSingleReparto(decimal repartoid)
        {
            try
            {
                if (CoordinatumManager.GetSingleReparto(repartoid) != null)
                {
                    return Ok(CoordinatumManager.GetSingleReparto(repartoid));
                }
                return BadRequest();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpGet, Route("GetAll")]
        public IActionResult GetAll()
        {
            try
            {
                return Ok(CoordinatumManager.GetAll());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPut, Route("Update")]
        public IActionResult Update(CoordinatumDTO input)
        {
            try
            {
                if (CoordinatumManager.Update(input))
                {
                    return Ok(input);
                }
                return BadRequest(input);

            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpDelete, Route("Delete/{id}")]
        public IActionResult Delete(decimal id)
        {
            try
            {
                if (CoordinatumManager.Delete(id))
                {
                    return Ok();
                }
                return BadRequest(id);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
