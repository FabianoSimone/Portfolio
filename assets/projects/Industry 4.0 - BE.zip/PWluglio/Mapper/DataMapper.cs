﻿using PWluglio.DAL.Entities;
using PWluglio.DTO;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.Mapper
{
    public class DataMapper
    {
       
        public AnagrafeDTO MapAnagrafeToDTO(Anagrafe ent, bool value=false)
        {
            AnagrafeDTO dto = new AnagrafeDTO() {
                Id = ent.Id,
                Nome = ent.Nome.ToUpper(),
                Cognome = ent.Cognome.ToUpper(),
                DataNascita = ent.DataNascita,
                UserId=ent.UserId
                
            };
            if(value)
            {
                dto.User = MapUserToDTO(ent.User);
                dto.Operatores = ent.Operatores.Select(x => MapOperatoreToDTO(x)).ToList();
            }
            return dto;
        }
        public Anagrafe MapDTOToAnagrafe(AnagrafeDTO dto, bool value = false)
        {
            Anagrafe ent = new Anagrafe()
            {
                Id=dto.Id,
                Nome=dto.Nome.ToUpper(),
                Cognome=dto.Cognome.ToUpper(),
                DataNascita=dto.DataNascita,
                UserId = dto.UserId
            };
            if (value)
            {
                ent.User = MapDTOToUser(dto.User);
                ent.Operatores = dto.Operatores.Select(x => MapDTOToOperatore(x)).ToList();
            }
            return ent;
        }
        
        public ArticoloDTO MapArticoloToDTO(Articolo ent, bool value=false)
        {
            ArticoloDTO dto = new ArticoloDTO()
            {
                ArticoloId= ent.ArticoloId,
                Nome= ent.Nome.ToUpper(),
                Materiale= ent.Materiale.ToUpper(),
                Peso= ent.Peso
            };
            if (value)
            {
                dto.Ordines = ent.Ordines.Select(x => MapOrdineToDTO(x)).ToList();
            }
            return dto;
        }

        public Articolo MapDTOToArticolo(ArticoloDTO dto, bool value=false)
        {
            Articolo ent = new Articolo() {
                ArticoloId=dto.ArticoloId,
                Nome=dto.Nome.ToUpper(),
                Materiale=dto.Materiale.ToUpper(),
                Peso=dto.Peso
            };
            if (value)
            {
                ent.Ordines = dto.Ordines.Select(x => MapDTOToOrdine(x)).ToList();
            }
            return ent;
        }

        public CoordinatumDTO MapCoordinatumToDTO(Coordinatum ent, bool value=false)
        {
            CoordinatumDTO dto = new CoordinatumDTO()
            {
                Id=ent.Id,
                RepartoId=ent.RepartoId,
                MacchinaId=ent.MacchinaId,
                CoordinateX=ent.CoordinateX,
                CoordinateY=ent.CoordinateY
            };
            if(value)
            {
                dto.Macchina = MapMacchinaToDTO(ent.Macchina);
                dto.Reparto = MapRepartoToDTO(ent.Reparto);
            }
            return dto;
        }
        public Coordinatum MapDTOToCoordinatum(CoordinatumDTO dto, bool value=false)
        {
            Coordinatum ent = new Coordinatum()
            {
                Id = dto.Id,
                RepartoId = dto.RepartoId,
                MacchinaId = dto.MacchinaId,
                CoordinateX = dto.CoordinateX,
                CoordinateY = dto.CoordinateY
            };
            if (value)
            {
                ent.Macchina = MapDTOToMacchina(dto.Macchina);
                ent.Reparto = MapDTOToReparto(dto.Reparto);
            }
            return ent;
        }

        public ErroreDTO MapErroreToDTO(Errore ent, bool value=false)
        {
            ErroreDTO dto = new ErroreDTO()
            {
                ErroreId= ent.ErroreId,
                Tipo= ent.Tipo.ToUpper(),
                Descizione= ent.Descizione.ToUpper()
            };
            if(value)
            {
                dto.MacchinaErrores = ent.MacchinaErrores.Select(x=> MapMacchinaErroreToDTO(x)).ToList();
            }
            return dto;
        }

        public Errore MapDTOToErrore(ErroreDTO dto, bool value = false)
        {
            Errore ent = new Errore()
            {
                ErroreId = dto.ErroreId,
                Tipo = dto.Tipo.ToUpper(),
                Descizione = dto.Descizione.ToUpper()
            };
            if (value)
            {
                ent.MacchinaErrores = dto.MacchinaErrores.Select(x => MapDTOToMacchinaErrore(x)).ToList();
            }
            return ent;
        }

        public MacchinaErroreDTO MapMacchinaErroreToDTO(MacchinaErrore ent, bool value=false)
        {
            MacchinaErroreDTO dto = new MacchinaErroreDTO()
            {
                MacchinaId= ent.MacchinaId,
                ErroreId= ent.ErroreId,
                Priorita= ent.Priorita.ToUpper(),
                Data=ent.Data,
                Risolto=ent.Risolto
            };
            if (value)
            {
                dto.Errore = MapErroreToDTO(ent.Errore);
                dto.Macchina = MapMacchinaToDTO(ent.Macchina);
            }
            return dto;
        }

        public MacchinaErrore MapDTOToMacchinaErrore(MacchinaErroreDTO dto, bool value=false)
        {
            MacchinaErrore ent = new MacchinaErrore()
            {
                MacchinaId=dto.MacchinaId,
                ErroreId=dto.ErroreId,
                Priorita=dto.Priorita.ToUpper(),
                Data = dto.Data,
                Risolto = dto.Risolto
            };
            if(value)
            {
                ent.Errore = MapDTOToErrore(dto.Errore);
                ent.Macchina = MapDTOToMacchina(dto.Macchina);
            }
            return ent;
        }

        public MacchinaDTO MapMacchinaToDTO(Macchina ent, bool value=false)
        {
            MacchinaDTO dto = new MacchinaDTO()
            {
                MacchinaId = ent.MacchinaId,
                Nome = ent.Nome.ToUpper(),
                Tipolavorazione = ent.Tipolavorazione.ToUpper(),
                Quantitaprodotta = ent.Quantitaprodotta,
                RepartoId = ent.RepartoId,
                StatoId = ent.StatoId,
                Cancellato=ent.Cancellato
            };
            if(value)
            {
                dto.Reparto = MapRepartoToDTO(ent.Reparto);
                dto.Stato = MapStatoToDTO(ent.Stato);
                dto.Coordinata = ent.Coordinata.Select(x=>MapCoordinatumToDTO(x)).ToList();
                dto.MacchinaErrores = ent.MacchinaErrores.Select(x=>MapMacchinaErroreToDTO(x)).ToList();
                dto.MacchinaOrdines = ent.MacchinaOrdines.Select(x =>MapMacchinaOrdineToDTO(x)).ToList();
                dto.OperatoreMacchinas = ent.OperatoreMacchinas.Select(x=>MapOperatoreMacchinaToDTO(x)).ToList();
            }
            return dto;
        }

        public Macchina MapDTOToMacchina(MacchinaDTO dto, bool value=false)
        {
            Macchina ent = new Macchina()
            {
                MacchinaId = dto.MacchinaId,
                Nome = dto.Nome.ToUpper(),
                Tipolavorazione = dto.Tipolavorazione.ToUpper(),
                Quantitaprodotta = dto.Quantitaprodotta,
                RepartoId = dto.RepartoId,
                StatoId = dto.StatoId,
                Cancellato=dto.Cancellato
            };  
            if(value)
            {
                ent.Reparto = MapDTOToReparto(dto.Reparto);
                ent.Stato = MapDTOToStato(dto.Stato);
                ent.Coordinata = dto.Coordinata.Select(x => MapDTOToCoordinatum(x)).ToList();
                ent.MacchinaErrores = dto.MacchinaErrores.Select(x => MapDTOToMacchinaErrore(x)).ToList();
                ent.MacchinaOrdines = dto.MacchinaOrdines.Select(x => MapDTOToMacchinaOrdine(x)).ToList();
                ent.OperatoreMacchinas = dto.OperatoreMacchinas.Select(x =>MapDTOToOperatoreMacchina(x)).ToList();
            }
            return ent;
        }
        
        public MacchinaOrdineDTO MapMacchinaOrdineToDTO (MacchinaOrdine ent, bool value=false)
        {
            MacchinaOrdineDTO dto = new MacchinaOrdineDTO()
            {
                MacchinaId=ent.MacchinaId,
                OrdineId=ent.OrdineId
            };
            if(value)
            {
                dto.Macchina = MapMacchinaToDTO(ent.Macchina);
                dto.Ordine = MapOrdineToDTO(ent.Ordine);
            }
            return dto;
        }
        public MacchinaOrdine MapDTOToMacchinaOrdine(MacchinaOrdineDTO dto, bool value = false)
        {
            MacchinaOrdine ent = new MacchinaOrdine()
            {
                MacchinaId = dto.MacchinaId,
                OrdineId = dto.OrdineId
            };
            if (value)
            {
                ent.Macchina = MapDTOToMacchina(dto.Macchina);
                ent.Ordine = MapDTOToOrdine(dto.Ordine);
            }
            return ent;
        }

        public OperatoreDTO MapOperatoreToDTO(Operatore ent, bool value=false)
        {
            OperatoreDTO dto = new OperatoreDTO()
            {
                OperatorId = ent.OperatorId,
                Ruolo = ent.Ruolo.ToUpper(),
                AnagrafeId = ent.AnagrafeId,
                Immagine=ent.Immagine,
                Attivo=ent.Attivo  
            };
            if(value)
            {
                dto.Anagrafe = MapAnagrafeToDTO(ent.Anagrafe);
                dto.OperatoreMacchinas = ent.OperatoreMacchinas.Select(x =>MapOperatoreMacchinaToDTO(x)).ToList(); 
            }
            return dto;
        }

        public Operatore MapDTOToOperatore(OperatoreDTO dto, bool value=false)
        {
            Operatore ent = new Operatore()
            {
                OperatorId = dto.OperatorId,
                Ruolo = dto.Ruolo.ToUpper(),
                AnagrafeId = dto.AnagrafeId,
                Immagine=dto.Immagine,
                Attivo=dto.Attivo
            };
            if(value)
            {
                ent.Anagrafe = MapDTOToAnagrafe(dto.Anagrafe);
                ent.OperatoreMacchinas = dto.OperatoreMacchinas.Select(x=>MapDTOToOperatoreMacchina(x)).ToList();
            }
            return ent;
        }

        public OperatoreMacchinaDTO MapOperatoreMacchinaToDTO(OperatoreMacchina ent, bool value=false)
        {
            OperatoreMacchinaDTO dto = new OperatoreMacchinaDTO()
            {
                OperatoreId=ent.OperatoreId,
                MacchinaId=ent.MacchinaId
            };
            if(value)
            {
                dto.Macchina = MapMacchinaToDTO(ent.Macchina);
                dto.Operatore = MapOperatoreToDTO(ent.Operatore);
            }
            return dto;
        }
        public OperatoreMacchina MapDTOToOperatoreMacchina(OperatoreMacchinaDTO dto, bool value = false)
        {
            OperatoreMacchina ent = new OperatoreMacchina()
            {
                OperatoreId = dto.OperatoreId,
                MacchinaId = dto.MacchinaId
            };
            if (value)
            {
                ent.Macchina = MapDTOToMacchina(dto.Macchina);
                ent.Operatore = MapDTOToOperatore(dto.Operatore);
            }
            return ent;
        }
        public OrdineDTO MapOrdineToDTO(Ordine ent, bool value=false)
        {
            OrdineDTO dto = new OrdineDTO()
            {
                OrdineId=ent.OrdineId,
                Data=ent.Data,
                Quantita=ent.Quantita,   
                ArticoloId=ent.ArticoloId,
                MacchinaId=ent.MacchinaId

            };
            if(value)
            {
                dto.Articolo = MapArticoloToDTO(ent.Articolo);
                dto.MacchinaOrdines = ent.MacchinaOrdines.Select(x=>MapMacchinaOrdineToDTO(x)).ToList();
            }
            return dto;
        }

        public Ordine MapDTOToOrdine(OrdineDTO dto, bool value=false)
        {
            Ordine ent = new Ordine()
            {
                OrdineId = dto.OrdineId,
                Data = dto.Data,
                Quantita = dto.Quantita,
                ArticoloId = dto.ArticoloId,
                MacchinaId = dto.MacchinaId
            };
            if(value)
            {
                ent.Articolo = MapDTOToArticolo(dto.Articolo);
                ent.MacchinaOrdines = dto.MacchinaOrdines.Select(x => MapDTOToMacchinaOrdine(x)).ToList();
            }
            return ent;
        }

        public RepartoDTO MapRepartoToDTO(Reparto ent, bool value=false)
        {
            RepartoDTO dto = new RepartoDTO()
            {
                RepartoId=ent.RepartoId,
                NomeReparto=ent.NomeReparto.ToUpper(),
                ResponsabileId=ent.ResponsabileId,
                StabilimentoId=ent.StabilimentoId,
                Mappa=ent.Mappa,
                Cancellato=ent.Cancellato
            };
            if (value)
            {
                dto.Macchinas = ent.Macchinas.Select(x => MapMacchinaToDTO(x)).ToList();
            }
            return dto;
        }

        public Reparto MapDTOToReparto(RepartoDTO dto, bool value=false)
        {
            Reparto ent = new Reparto()
            {
                RepartoId = dto.RepartoId,
                NomeReparto = dto.NomeReparto.ToUpper(),
                ResponsabileId = dto.ResponsabileId,
                StabilimentoId = dto.StabilimentoId,
                Mappa=dto.Mappa,
                Cancellato = dto.Cancellato

            };
            if(value)
            {
                ent.Macchinas = dto.Macchinas.Select(x=>MapDTOToMacchina(x)).ToList();
            }
            return ent;
        }

        public StabilimentoDTO MapStabilimentoToDTO(Stabilimento ent)
        {
            StabilimentoDTO dto = new StabilimentoDTO()
            {
                StabilimentoId=ent.StabilimentoId,
                Nome=ent.Nome.ToUpper(),
                Citta=ent.Citta.ToUpper(),
                Mappa=ent.Mappa
            };

            return dto;
        }

        public Stabilimento MapDTOToStabilimento(StabilimentoDTO dto)
        {
            Stabilimento ent = new Stabilimento()
            {
                StabilimentoId = dto.StabilimentoId,
                Nome = dto.Nome.ToUpper(),
                Citta = dto.Citta.ToUpper(),
                Mappa=dto.Mappa
            };
            return ent;
        }

        public StatoDTO MapStatoToDTO(Stato ent, bool value=false)
        {
            StatoDTO dto = new StatoDTO()
            {
                StatoId=ent.StatoId,
                Stato=ent.Stato1.ToUpper()
            };
            if(value)
            {
                dto.Macchinas = ent.Macchinas.Select(x=> MapMacchinaToDTO(x)).ToList();
            }
            return dto;
        }

        public Stato MapDTOToStato(StatoDTO dto, bool value=false)
        {
            Stato ent = new Stato()
            {
                StatoId = dto.StatoId,
                Stato1 = dto.Stato.ToUpper()
            };
            if (value)
            {
                ent.Macchinas = dto.Macchinas.Select(x => MapDTOToMacchina(x)).ToList();
            }
            return ent;
        }

        public TemplateDTO MapTemplateToDTO(Template ent)
        {
            TemplateDTO dto = new TemplateDTO()
            {
                TemplateId=ent.TemplateId,
                Html=ent.Html,
                RepartoId=ent.RepartoId,
                StabilimentoId=ent.StabilimentoId,
                Reparto=MapRepartoToDTO(ent.Reparto),
                Stabilimento=MapStabilimentoToDTO(ent.Stabilimento)
            };
            return dto;
        }

        public Template MapDTOToTemplate(TemplateDTO dto)
        {
            Template ent = new Template()
            {
                TemplateId = dto.TemplateId,
                Html = dto.Html,
                RepartoId = dto.RepartoId,
                StabilimentoId = dto.StabilimentoId,
                Reparto = MapDTOToReparto(dto.Reparto),
                Stabilimento = MapDTOToStabilimento(dto.Stabilimento)
            };
            return ent;
        }

        public UserDTO MapUserToDTO(User ent, bool value=false)
        {
            UserDTO dto = new UserDTO()
            {
                Username=ent.Username,
                Password=ent.Username,
                Email=ent.Email,
                Admin=ent.Admin
            };
            if(value)
            {
                dto.Anagraves = ent.Anagraves.Select(x=>MapAnagrafeToDTO(x)).ToList();
            }
            return dto;
        }
        public User MapDTOToUser(UserDTO dto, bool value = false)
        {
            User ent = new User()
            {
                Username = dto.Username,
                Password = dto.Username,
                Email = dto.Email,
                Admin = dto.Admin
            };
            if (value)
            {
                ent.Anagraves = dto.Anagraves.Select(x => MapDTOToAnagrafe(x)).ToList();
            }
            return ent;
        }

    }  
}