﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class StatoDTO
    {
        [Required]
        public decimal StatoId { get; set; }
        [Required]
        public string Stato { get; set; }

        public  List<MacchinaDTO> Macchinas { get; set; }
    }
}
