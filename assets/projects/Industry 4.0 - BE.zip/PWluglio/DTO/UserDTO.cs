﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class UserDTO : IdentityUser<int>
    {
        [Required]
        public string Username { get; set; }
        [Required]
        public string Password { get; set; }
        //[Required]
        //public string Email { get; set; }
        [Required]
        public bool Admin { get; set; }

        public  List<AnagrafeDTO> Anagraves { get; set; }
    }
}
