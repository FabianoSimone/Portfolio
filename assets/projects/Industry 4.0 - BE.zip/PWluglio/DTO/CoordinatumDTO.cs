﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class CoordinatumDTO
    {
        [Required]
        public decimal Id { get; set; }
        public decimal? RepartoId { get; set; }
        public decimal? MacchinaId { get; set; }
        /*
        [Required]
        public decimal StabilimentoId { get; set; }
        */
        [Required]
        public decimal CoordinateX { get; set; }
        [Required]
        public decimal CoordinateY { get; set; }

        public  RepartoDTO Reparto { get; set; }
        public  MacchinaDTO Macchina { get; set; }
        public  StabilimentoDTO Stabilimento { get; set; }
    }
}
