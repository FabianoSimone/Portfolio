﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class RepartoDTO
    {
        [Required]
        public decimal RepartoId { get; set; }
        [Required]
        public string NomeReparto { get; set; }
        [Required]
        public decimal ResponsabileId { get; set; }
        [Required]
        public decimal StabilimentoId { get; set; }
        
        public  OperatoreDTO Responsabile { get; set; }
        public  StabilimentoDTO Stabilimento { get; set; }
        public decimal CoordinateX { get; set; }
        public decimal CoordinateY { get; set; }
        public string NomeResponsabile { get; set; }
        public string CognomeResponsabile { get; set; }
        public bool Cancellato { get; set; }
        public decimal statoReparto { get;set; }
        [Required]
        public string Mappa { get; set; }
        public  List<MacchinaDTO> Macchinas { get; set; }
    }
}
