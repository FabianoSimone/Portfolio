﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class StabilimentoDTO
    {
        [Required]
        public decimal StabilimentoId { get; set; }
        [Required]
        public string Nome { get; set; }
        [Required]
        public string Citta { get; set; }
        public string Mappa { get; set; }
        public  List<CoordinatumDTO> Coordinata { get; set; }
        public  List<RepartoDTO> Repartos { get; set; }
    }
}
