﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class ArticoloDTO
    {
        public decimal ArticoloId { get; set; }
        [Required]
        public string Nome { get; set; }
        [Required]
        public string Materiale { get; set; }
        [Required]
        public decimal Peso { get; set; }
        public List<OrdineDTO> Ordines { get; set; }

    }
}
