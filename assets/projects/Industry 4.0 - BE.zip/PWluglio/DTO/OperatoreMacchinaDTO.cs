﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class OperatoreMacchinaDTO
    {
        [Required]
        public decimal OperatoreId { get; set; }
        [Required]
        public decimal MacchinaId { get; set; }
        public string NomeOperatore { get; set; }
        public string CognomeOperatore { get; set; }
        public  MacchinaDTO Macchina { get; set; }
        public  OperatoreDTO Operatore { get; set; }
    }
}
