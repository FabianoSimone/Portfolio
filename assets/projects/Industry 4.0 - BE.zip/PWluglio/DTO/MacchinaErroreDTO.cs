﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class MacchinaErroreDTO
    {
        [Required]
        public decimal MacchinaId { get; set; }
        [Required]
        public decimal ErroreId { get; set; }
        [Required]
        public string Priorita { get; set; }
        [Required]
        public DateTime Data { get; set; }
        [Required]
        public bool Risolto { get; set; }
        
        public  ErroreDTO Errore { get; set; }
        public MacchinaDTO Macchina { get; set; }

        public decimal RepartoId { get; set; }
        public string NomeMacchina { get; set; }
        public string TipoErrore { get; set; }
        public string DescrizioneErrore { get; set; }

    }
}
