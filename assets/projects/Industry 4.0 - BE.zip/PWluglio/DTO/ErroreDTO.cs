﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class ErroreDTO
    {
        [Required]
        public decimal ErroreId { get; set; }
        [Required]
        public string Tipo { get; set; }
        [Required]
        public string Descizione { get; set; }
        [Required]
        public List<MacchinaErroreDTO> MacchinaErrores { get; set; }

      
    }
}
