﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class TemplateDTO
    {
        [Required]
        public decimal TemplateId { get; set; }
        [Required]
        public byte[] Html { get; set; }
        [Required]
        public decimal RepartoId { get; set; }
        [Required]
        public decimal StabilimentoId { get; set; }

        public  RepartoDTO Reparto { get; set; }
        public  StabilimentoDTO Stabilimento { get; set; }
    }
}
