﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class MacchinaDTO
    {
        [Required]
        public decimal MacchinaId { get; set; }
        [Required]
        public string Nome { get; set; }
        [Required]
        public string Tipolavorazione { get; set; }
        [Required]
        public decimal Quantitaprodotta { get; set; }
        [Required]
        public decimal RepartoId { get; set; }
        [Required]
        public decimal StatoId { get; set; }
        [Required]
        public decimal CoordinateX { get; set; }
        [Required]
        public decimal CoordinateY { get; set; }
        public bool Cancellato { get; set; }
        public  RepartoDTO Reparto { get; set; }
        public  StatoDTO Stato { get; set; }
        public  List<CoordinatumDTO> Coordinata { get; set; }
        public  List<MacchinaErroreDTO> MacchinaErrores { get; set; }
        public  List<MacchinaOrdineDTO> MacchinaOrdines { get; set; }
        public  List<OperatoreMacchinaDTO> OperatoreMacchinas { get; set; }
    }
}
