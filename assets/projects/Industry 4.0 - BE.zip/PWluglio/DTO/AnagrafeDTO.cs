﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class AnagrafeDTO
    {
        public decimal Id { get; set; }
        [Required]
        public string Nome { get; set; }
        [Required]
        public string Cognome { get; set; }
        [Required]
        public DateTime DataNascita { get; set; }
        [Required]
        public string UserId { get; set; }
        public  UserDTO User { get; set; }

        public List<OperatoreDTO> Operatores { get; set; }
    }
}
