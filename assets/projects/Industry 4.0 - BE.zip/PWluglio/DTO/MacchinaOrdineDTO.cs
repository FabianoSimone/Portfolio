﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class MacchinaOrdineDTO
    {
        [Required]
        public decimal MacchinaId { get; set; }
        [Required]
        public decimal OrdineId { get; set; }

        public  MacchinaDTO Macchina { get; set; }
        public  OrdineDTO Ordine { get; set; }
    }
}
