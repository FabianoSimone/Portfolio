﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class OperatoreDTO
    {
        [Required]
        public decimal OperatorId { get; set; }
        [Required]
        public string Ruolo { get; set; }
        [Required]
        public decimal AnagrafeId { get; set; }
        public string Immagine { get; set; }
        [Required]
        public bool Attivo { get; set; }
        public AnagrafeDTO Anagrafe { get; set; }
        public  List<OperatoreMacchinaDTO> OperatoreMacchinas { get; set; }
        public  List<RepartoDTO> Repartos { get; set; }
    }
}
