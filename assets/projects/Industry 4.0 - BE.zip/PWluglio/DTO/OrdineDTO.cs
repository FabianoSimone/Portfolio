﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace PWluglio.DTO
{
    public class OrdineDTO
    {
        [Required]
        public decimal OrdineId { get; set; }
        [Required]
        public DateTime Data { get; set; }
        [Required]
        public decimal Quantita { get; set; }
        [Required]
        public decimal ArticoloId { get; set; }
        [Required]
        public decimal MacchinaId { get; set; }

        public  ArticoloDTO Articolo { get; set; }
        public  List<MacchinaOrdineDTO> MacchinaOrdines { get; set; }
    }
}
